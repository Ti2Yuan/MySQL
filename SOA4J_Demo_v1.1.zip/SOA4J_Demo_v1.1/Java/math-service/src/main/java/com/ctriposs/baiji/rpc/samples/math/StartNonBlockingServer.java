package com.ctriposs.baiji.rpc.samples.math;

import com.ctriposs.baiji.rpc.common.BaijiContract;
import com.ctriposs.baiji.rpc.server.BaijiServiceHost;
import com.ctriposs.baiji.rpc.server.HostConfig;
import com.ctriposs.baiji.rpc.server.ServiceHost;
import com.ctriposs.baiji.rpc.server.netty.NonBlockingHttpServerBuilder;
import com.ctriposs.baiji.rpc.server.registry.EtcdServiceRegistry;
import com.ctriposs.baiji.rpc.server.registry.ServiceInfo;
import com.ctriposs.baiji.rpc.server.registry.ServiceRegistry;
import io.netty.channel.ChannelOption;

public final class StartNonBlockingServer {

    public static void main(String[] args) throws Exception {
        HostConfig config = new HostConfig();
        config.debugMode = true;
        ServiceHost host = new BaijiServiceHost(config, MathServiceImpl.class);

        NonBlockingHttpServerBuilder builder = new NonBlockingHttpServerBuilder(8080);

        builder.serviceHost(host)
                .withSelectorCount(1)
                .executorThreadCount(10)
                .serverSocketOption(ChannelOption.SO_BACKLOG, 100)
                .clientSocketOption(ChannelOption.TCP_NODELAY, true)
                .build().startWithoutWaitingForShutdown();

        ServiceRegistry registry = new EtcdServiceRegistry("http://etcd.soa.fws.qa.nt.ctripcorp.com/");
        BaijiContract contract = MathService.class.getAnnotation(BaijiContract.class);
        ServiceInfo service = new ServiceInfo.Builder().serviceName(contract.serviceName())
                .serviceNamespace(contract.serviceNamespace())
                .subEnv("dev")
                .port(8080).build();
        registry.addService(service);
        registry.run();
    }
}
