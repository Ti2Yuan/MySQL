package com.ctriposs.baiji.rpc.samples.math;

import com.ctriposs.baiji.rpc.client.ServiceClientConfig;

/**
 * Created by yqdong on 2014/9/8.
 */
public class Client {

    public static void main(String[] args) throws Exception {
        try {
            ServiceClientConfig config = new ServiceClientConfig();
            config.setFxConfigServiceUrl("http://ws.config.framework.fws.qa.nt.ctripcorp.com/Configws/");
            config.setSubEnv("dev");
            config.setAppId("921999");
            MathServiceClient.initialize(config);

//            MathServiceClient client = MathServiceClient.getInstance();
            MathServiceClient client = MathServiceClient.getInstance("http://localhost:8080/");
            GetFactorialRequestType request = new GetFactorialRequestType(5L);
            GetFactorialResponseType response = client.getFactorial(request);
            System.out.println(response.getResponseStatus());
            System.out.println(response.getResult());
        } catch (Throwable t) {
            t.printStackTrace();
        } finally {
            System.exit(0);
        }
    }
}
