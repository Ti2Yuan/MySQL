namespace CTripOSS.Baiji.Rpc.Samples.Math
{
    using System.Threading.Tasks;
    using CTripOSS.Baiji.Rpc.Client;
    using CTripOSS.Baiji.Rpc.Common.Types;

    public class MathServiceClient : ServiceClientBase<MathServiceClient>
    {
        public const string OriginalServiceName = "MathService";

        public const string OriginalServiceNamespace = "http://soa.ctrip.com/framework/soa4j/sample/math/v1";

        public const string CodeGeneratorVersion = "1.1.0.0";

        private MathServiceClient(string baseUri)
            : base(baseUri)
        {
        }

        private MathServiceClient(string serviceName, string serviceNamespace, string subEnv)
            : base(serviceName, serviceNamespace, subEnv)
        {
        }

        public GetFactorialResponseType GetFactorial(GetFactorialRequestType request)
        {
            return base.Invoke<GetFactorialRequestType, GetFactorialResponseType>("GetFactorial", request);
        }
        public Task<GetFactorialResponseType> CreateAsyncTaskOfGetFactorial(GetFactorialRequestType request)
        {
            return base.CreateAsyncTask<GetFactorialRequestType, GetFactorialResponseType>("GetFactorial", request);
        }
        public Task<GetFactorialResponseType> StartIOCPTaskOfGetFactorial(GetFactorialRequestType request)
        {
            return base.StartIOCPTask<GetFactorialRequestType, GetFactorialResponseType>("GetFactorial", request);
        }
        public CTripOSS.Baiji.Rpc.Common.Types.CheckHealthResponseType CheckHealth(CTripOSS.Baiji.Rpc.Common.Types.CheckHealthRequestType request)
        {
            return base.Invoke<CTripOSS.Baiji.Rpc.Common.Types.CheckHealthRequestType, CTripOSS.Baiji.Rpc.Common.Types.CheckHealthResponseType>("CheckHealth", request);
        }
        public Task<CTripOSS.Baiji.Rpc.Common.Types.CheckHealthResponseType> CreateAsyncTaskOfCheckHealth(CTripOSS.Baiji.Rpc.Common.Types.CheckHealthRequestType request)
        {
            return base.CreateAsyncTask<CTripOSS.Baiji.Rpc.Common.Types.CheckHealthRequestType, CTripOSS.Baiji.Rpc.Common.Types.CheckHealthResponseType>("CheckHealth", request);
        }
        public Task<CTripOSS.Baiji.Rpc.Common.Types.CheckHealthResponseType> StartIOCPTaskOfCheckHealth(CTripOSS.Baiji.Rpc.Common.Types.CheckHealthRequestType request)
        {
            return base.StartIOCPTask<CTripOSS.Baiji.Rpc.Common.Types.CheckHealthRequestType, CTripOSS.Baiji.Rpc.Common.Types.CheckHealthResponseType>("CheckHealth", request);
        }
    }
}