namespace CTripOSS.Baiji.Rpc.Samples.Math
{
    using System;
    using System.Text;
    using System.Linq;
    using System.Collections;
    using System.Collections.Generic;
    using CTripOSS.Baiji.Exceptions;
    using CTripOSS.Baiji.Specific;
    using CTripOSS.Baiji.Utils;
    using CTripOSS.Baiji.Rpc.Common;

    public partial class GetFactorialRequestType : SpecificRecordBase
    {
        public static readonly CTripOSS.Baiji.Schema.Schema SCHEMA = CTripOSS.Baiji.Schema.Schema.Parse("{\"type\":\"record\",\"name\":\"GetFactorialRequestType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Samples.Math\",\"doc\":null,\"fields\":[{\"name\":\"number\",\"type\":[\"long\",\"null\"]}]}");

        public GetFactorialRequestType(
            long? number
        )
        {
            this.Number = number;
        }

        public GetFactorialRequestType()
        {
        }

        public long? Number { get; set; }


        public override CTripOSS.Baiji.Schema.Schema GetSchema()
        {
            return SCHEMA;
        }

        // Used by DatumWriter. Applications should not call.
        public override object Get(int fieldPos)
        {
            switch (fieldPos)
            {
                case 0: return this.Number;
                default: throw new BaijiRuntimeException("Bad index " + fieldPos + " in Get()");
            }
        }

        // Used by DatumReader. Applications should not call.
        public override void Put(int fieldPos, object fieldValue)
        {
            switch (fieldPos)
            {
                case 0: this.Number = (long?)fieldValue; break;
                default: throw new BaijiRuntimeException("Bad index " + fieldPos + " in Put()");
            }
        }

        public override bool Equals(object that)
        {
            var other = that as GetFactorialRequestType;
            if (other == null) return false;
            if (ReferenceEquals(this, other)) return true;

            return 
                Equals(Number, other.Number);
        }

        public override int GetHashCode()
        {
            int result = 1;

            result = (result * 397) ^ (Number == null ? 0 : Number.GetHashCode());

            return result;
        }

        public override string ToString()
        {
            var __sb = new StringBuilder("GetFactorialRequestType(");

            bool __first = true;
            if (Number != null)
            {
                if(!__first) { __sb.Append(", "); }
                __first = false;
                __sb.Append("Number: ");
                __sb.Append(Number);
            }

            __sb.Append(")");
            return __sb.ToString();
        }
    }
}