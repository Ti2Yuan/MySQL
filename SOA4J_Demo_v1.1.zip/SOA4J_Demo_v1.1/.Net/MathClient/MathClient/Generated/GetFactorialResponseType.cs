namespace CTripOSS.Baiji.Rpc.Samples.Math
{
    using System;
    using System.Text;
    using System.Linq;
    using System.Collections;
    using System.Collections.Generic;
    using CTripOSS.Baiji.Exceptions;
    using CTripOSS.Baiji.Specific;
    using CTripOSS.Baiji.Utils;
    using CTripOSS.Baiji.Rpc.Common;

    public partial class GetFactorialResponseType : SpecificRecordBase, IHasResponseStatus
    {
        public static readonly CTripOSS.Baiji.Schema.Schema SCHEMA = CTripOSS.Baiji.Schema.Schema.Parse("{\"type\":\"record\",\"name\":\"GetFactorialResponseType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Samples.Math\",\"doc\":null,\"fields\":[{\"name\":\"responseStatus\",\"type\":[{\"type\":\"record\",\"name\":\"ResponseStatusType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Common.Types\",\"doc\":null,\"fields\":[{\"name\":\"timestamp\",\"type\":[\"datetime\",\"null\"]},{\"name\":\"ack\",\"type\":[{\"type\":\"enum\",\"name\":\"AckCodeType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Common.Types\",\"doc\":null,\"symbols\":[\"Success\",\"Failure\",\"Warning\",\"PartialFailure\"]},\"null\"]},{\"name\":\"errors\",\"type\":[{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"ErrorDataType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Common.Types\",\"doc\":null,\"fields\":[{\"name\":\"message\",\"type\":[\"string\",\"null\"]},{\"name\":\"errorCode\",\"type\":[\"string\",\"null\"]},{\"name\":\"stackTrace\",\"type\":[\"string\",\"null\"]},{\"name\":\"severityCode\",\"type\":[{\"type\":\"enum\",\"name\":\"SeverityCodeType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Common.Types\",\"doc\":null,\"symbols\":[\"Error\",\"Warning\"]},\"null\"]},{\"name\":\"errorFields\",\"type\":[{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"ErrorFieldType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Common.Types\",\"doc\":null,\"fields\":[{\"name\":\"fieldName\",\"type\":[\"string\",\"null\"]},{\"name\":\"errorCode\",\"type\":[\"string\",\"null\"]},{\"name\":\"message\",\"type\":[\"string\",\"null\"]}]}},\"null\"]},{\"name\":\"errorClassification\",\"type\":[{\"type\":\"enum\",\"name\":\"ErrorClassificationCodeType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Common.Types\",\"doc\":null,\"symbols\":[\"ServiceError\",\"ValidationError\",\"FrameworkError\",\"SLAError\",\"SecurityError\"]},\"null\"]}]}},\"null\"]},{\"name\":\"build\",\"type\":[\"string\",\"null\"]},{\"name\":\"version\",\"type\":[\"string\",\"null\"]},{\"name\":\"extension\",\"type\":[{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"ExtensionType\",\"namespace\":\"CTripOSS.Baiji.Rpc.Common.Types\",\"doc\":null,\"fields\":[{\"name\":\"id\",\"type\":[\"int\",\"null\"]},{\"name\":\"version\",\"type\":[\"string\",\"null\"]},{\"name\":\"contentType\",\"type\":[\"string\",\"null\"]},{\"name\":\"value\",\"type\":[\"string\",\"null\"]}]}},\"null\"]}]},\"null\"]},{\"name\":\"result\",\"type\":[\"long\",\"null\"]}]}");

        public GetFactorialResponseType(
            CTripOSS.Baiji.Rpc.Common.Types.ResponseStatusType responseStatus,
            long? result
        )
        {
            this.ResponseStatus = responseStatus;
            this.Result = result;
        }

        public GetFactorialResponseType()
        {
        }

        public CTripOSS.Baiji.Rpc.Common.Types.ResponseStatusType ResponseStatus { get; set; }

        public long? Result { get; set; }


        public override CTripOSS.Baiji.Schema.Schema GetSchema()
        {
            return SCHEMA;
        }

        // Used by DatumWriter. Applications should not call.
        public override object Get(int fieldPos)
        {
            switch (fieldPos)
            {
                case 0: return this.ResponseStatus;
                case 1: return this.Result;
                default: throw new BaijiRuntimeException("Bad index " + fieldPos + " in Get()");
            }
        }

        // Used by DatumReader. Applications should not call.
        public override void Put(int fieldPos, object fieldValue)
        {
            switch (fieldPos)
            {
                case 0: this.ResponseStatus = (CTripOSS.Baiji.Rpc.Common.Types.ResponseStatusType)fieldValue; break;
                case 1: this.Result = (long?)fieldValue; break;
                default: throw new BaijiRuntimeException("Bad index " + fieldPos + " in Put()");
            }
        }

        public override bool Equals(object that)
        {
            var other = that as GetFactorialResponseType;
            if (other == null) return false;
            if (ReferenceEquals(this, other)) return true;

            return 
                Equals(ResponseStatus, other.ResponseStatus) &&
                Equals(Result, other.Result);
        }

        public override int GetHashCode()
        {
            int result = 1;

            result = (result * 397) ^ (ResponseStatus == null ? 0 : ResponseStatus.GetHashCode());
            result = (result * 397) ^ (Result == null ? 0 : Result.GetHashCode());

            return result;
        }

        public override string ToString()
        {
            var __sb = new StringBuilder("GetFactorialResponseType(");

            bool __first = true;
            if (ResponseStatus != null)
            {
                if(!__first) { __sb.Append(", "); }
                __first = false;
                __sb.Append("ResponseStatus: ");
                __sb.Append(ResponseStatus == null ? "" : ResponseStatus.ToString());
            }
            if (Result != null)
            {
                if(!__first) { __sb.Append(", "); }
                __first = false;
                __sb.Append("Result: ");
                __sb.Append(Result);
            }

            __sb.Append(")");
            return __sb.ToString();
        }
    }
}