﻿using System;

namespace CTripOSS.Baiji.Rpc.Samples.Math
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //var client = MathServiceClient.GetInstance();
            var client = MathServiceClient.GetInstance("http://localhost:8080/");
            var request = new GetFactorialRequestType(5);
            var response = client.GetFactorial(request);
            Console.WriteLine(response.ResponseStatus);
            Console.WriteLine(response.Result);
        }
    }
}
